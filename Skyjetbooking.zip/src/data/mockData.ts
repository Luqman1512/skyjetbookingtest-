import { Flight } from '@/types';

export const mockFlights: Flight[] = [
  {
    id: '1',
    airline: 'AirAsia',
    airlineLogo: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=100&q=80',
    flightNumber: 'AK101',
    origin: 'Kuala Lumpur (KUL)',
    destination: 'Tokyo (NRT)',
    departureTime: '08:00',
    arrivalTime: '16:30',
    duration: '7h 30m',
    price: 1299,
    class: 'Economy',
    availableSeats: 45,
    date: '2025-02-15'
  },
  {
    id: '2',
    airline: 'Malaysia Airlines',
    airlineLogo: 'https://images.unsplash.com/photo-1464037866556-6812c9d1c72e?w=100&q=80',
    flightNumber: 'MH370',
    origin: 'Kuala Lumpur (KUL)',
    destination: 'Paris (CDG)',
    departureTime: '23:45',
    arrivalTime: '07:15',
    duration: '13h 30m',
    price: 2899,
    class: 'Business',
    availableSeats: 12,
    date: '2025-02-15'
  },
  {
    id: '3',
    airline: 'Emirates',
    airlineLogo: 'https://images.unsplash.com/photo-1474302770737-173ee21bab63?w=100&q=80',
    flightNumber: 'EK343',
    origin: 'Kuala Lumpur (KUL)',
    destination: 'Dubai (DXB)',
    departureTime: '03:30',
    arrivalTime: '06:45',
    duration: '7h 15m',
    price: 1899,
    class: 'Economy',
    availableSeats: 28,
    date: '2025-02-15'
  },
  {
    id: '4',
    airline: 'AirAsia',
    airlineLogo: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=100&q=80',
    flightNumber: 'AK205',
    origin: 'Kuala Lumpur (KUL)',
    destination: 'Singapore (SIN)',
    departureTime: '10:15',
    arrivalTime: '11:20',
    duration: '1h 05m',
    price: 299,
    class: 'Economy',
    availableSeats: 67,
    date: '2025-02-15'
  },
  {
    id: '5',
    airline: 'Emirates',
    airlineLogo: 'https://images.unsplash.com/photo-1474302770737-173ee21bab63?w=100&q=80',
    flightNumber: 'EK415',
    origin: 'Kuala Lumpur (KUL)',
    destination: 'London (LHR)',
    departureTime: '22:00',
    arrivalTime: '05:30',
    duration: '14h 30m',
    price: 4299,
    class: 'First',
    availableSeats: 8,
    date: '2025-02-15'
  },
  {
    id: '6',
    airline: 'Malaysia Airlines',
    airlineLogo: 'https://images.unsplash.com/photo-1464037866556-6812c9d1c72e?w=100&q=80',
    flightNumber: 'MH88',
    origin: 'Kuala Lumpur (KUL)',
    destination: 'Bangkok (BKK)',
    departureTime: '14:30',
    arrivalTime: '15:45',
    duration: '2h 15m',
    price: 399,
    class: 'Economy',
    availableSeats: 52,
    date: '2025-02-15'
  }
];

export const popularDestinations = [
  {
    city: 'Tokyo',
    country: 'Japan',
    image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&q=80',
    price: 1299
  },
  {
    city: 'Paris',
    country: 'France',
    image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&q=80',
    price: 2899
  },
  {
    city: 'Dubai',
    country: 'UAE',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&q=80',
    price: 1899
  },
  {
    city: 'Singapore',
    country: 'Singapore',
    image: 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=800&q=80',
    price: 299
  }
];