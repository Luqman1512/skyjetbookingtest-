import { useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, Download, Printer, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import { Booking } from '@/types';

export default function ConfirmationPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const booking = (location.state as any)?.booking as Booking;

  if (!booking) {
    navigate('/');
    return null;
  }

  const handleDownload = () => {
    // Mock PDF download
    alert('E-ticket PDF would be downloaded here');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, type: 'spring' }}
            className="flex justify-center mb-8"
          >
            <div className="bg-green-100 p-6 rounded-full">
              <CheckCircle2 className="h-24 w-24 text-green-600" />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-center mb-8"
          >
            <h1 className="text-4xl font-bold mb-2">Booking Confirmed!</h1>
            <p className="text-gray-600">Your flight has been successfully booked</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="mb-6">
              <CardContent className="p-6 space-y-4">
                <div className="flex justify-between items-center pb-4 border-b">
                  <span className="text-gray-600">Booking ID</span>
                  <span className="font-bold">{booking.id}</span>
                </div>

                <div className="space-y-3">
                  <h3 className="font-bold text-lg">Flight Details</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Airline</p>
                      <p className="font-medium">{booking.flight.airline}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Flight Number</p>
                      <p className="font-medium">{booking.flight.flightNumber}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">From</p>
                      <p className="font-medium">{booking.flight.origin}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">To</p>
                      <p className="font-medium">{booking.flight.destination}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Departure</p>
                      <p className="font-medium">{booking.flight.date} at {booking.flight.departureTime}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Arrival</p>
                      <p className="font-medium">{booking.flight.date} at {booking.flight.arrivalTime}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 pt-4 border-t">
                  <h3 className="font-bold text-lg">Passenger Details</h3>
                  {booking.passengers.map((passenger, index) => (
                    <div key={index} className="text-sm">
                      <p className="font-medium">
                        {passenger.firstName} {passenger.lastName}
                      </p>
                      <p className="text-gray-600">Seat: {booking.seats[index]}</p>
                    </div>
                  ))}
                </div>

                <div className="flex justify-between items-center pt-4 border-t">
                  <span className="text-lg font-bold">Total Paid</span>
                  <span className="text-2xl font-bold text-[#007bff]">
                    RM {booking.totalPrice}
                  </span>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button 
                onClick={handleDownload}
                variant="outline"
                className="gap-2"
              >
                <Download className="h-4 w-4" />
                Download E-Ticket
              </Button>
              <Button 
                onClick={handlePrint}
                variant="outline"
                className="gap-2"
              >
                <Printer className="h-4 w-4" />
                Print Receipt
              </Button>
              <Button 
                onClick={() => navigate('/')}
                className="gap-2 bg-[#007bff] hover:bg-[#0056b3]"
              >
                <Home className="h-4 w-4" />
                Back to Home
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}