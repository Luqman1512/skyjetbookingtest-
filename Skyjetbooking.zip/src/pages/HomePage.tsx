import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Calendar, Users, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { popularDestinations } from '@/data/mockData';
import { motion } from 'framer-motion';

export default function HomePage() {
  const navigate = useNavigate();
  const [searchData, setSearchData] = useState({
    origin: '',
    destination: '',
    departureDate: '',
    returnDate: '',
    passengers: '1',
    class: 'Economy'
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/search', { state: searchData });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div 
        className="relative h-[600px] bg-cover bg-center flex items-center justify-center"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 123, 255, 0.7), rgba(0, 123, 255, 0.7)), url(https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=1600&q=80)',
        }}
      >
        <div className="container mx-auto px-4 z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-8"
          >
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">
              Discover Your Next Adventure
            </h1>
            <p className="text-xl text-white/90">
              Book flights to destinations worldwide with ease
            </p>
          </motion.div>

          {/* Search Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="max-w-5xl mx-auto shadow-2xl">
              <CardContent className="p-6">
                <form onSubmit={handleSearch} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {/* Origin */}
                    <div className="space-y-2">
                      <Label htmlFor="origin" className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-[#007bff]" />
                        From
                      </Label>
                      <Input
                        id="origin"
                        placeholder="Kuala Lumpur (KUL)"
                        value={searchData.origin}
                        onChange={(e) => setSearchData({ ...searchData, origin: e.target.value })}
                        required
                      />
                    </div>

                    {/* Destination */}
                    <div className="space-y-2">
                      <Label htmlFor="destination" className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-[#007bff]" />
                        To
                      </Label>
                      <Input
                        id="destination"
                        placeholder="Tokyo (NRT)"
                        value={searchData.destination}
                        onChange={(e) => setSearchData({ ...searchData, destination: e.target.value })}
                        required
                      />
                    </div>

                    {/* Departure Date */}
                    <div className="space-y-2">
                      <Label htmlFor="departureDate" className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-[#007bff]" />
                        Departure
                      </Label>
                      <Input
                        id="departureDate"
                        type="date"
                        value={searchData.departureDate}
                        onChange={(e) => setSearchData({ ...searchData, departureDate: e.target.value })}
                        required
                      />
                    </div>

                    {/* Return Date */}
                    <div className="space-y-2">
                      <Label htmlFor="returnDate" className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-[#007bff]" />
                        Return
                      </Label>
                      <Input
                        id="returnDate"
                        type="date"
                        value={searchData.returnDate}
                        onChange={(e) => setSearchData({ ...searchData, returnDate: e.target.value })}
                      />
                    </div>

                    {/* Passengers */}
                    <div className="space-y-2">
                      <Label htmlFor="passengers" className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-[#007bff]" />
                        Passengers
                      </Label>
                      <Select value={searchData.passengers} onValueChange={(value) => setSearchData({ ...searchData, passengers: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6].map((num) => (
                            <SelectItem key={num} value={num.toString()}>
                              {num} {num === 1 ? 'Passenger' : 'Passengers'}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Class */}
                    <div className="space-y-2">
                      <Label htmlFor="class">Class</Label>
                      <Select value={searchData.class} onValueChange={(value) => setSearchData({ ...searchData, class: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Economy">Economy</SelectItem>
                          <SelectItem value="Business">Business</SelectItem>
                          <SelectItem value="First">First Class</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-[#007bff] hover:bg-[#0056b3] text-lg py-6 transition-all hover:scale-[1.02]"
                  >
                    <Search className="mr-2 h-5 w-5" />
                    Search Flights
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      {/* Popular Destinations */}
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-center mb-12 text-gray-900">
            Popular Destinations
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularDestinations.map((dest, index) => (
              <motion.div
                key={dest.city}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-[1.02] cursor-pointer">
                  <div className="relative h-48">
                    <img 
                      src={dest.image} 
                      alt={dest.city}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <h3 className="text-2xl font-bold">{dest.city}</h3>
                      <p className="text-sm">{dest.country}</p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">From</span>
                      <span className="text-2xl font-bold text-[#007bff]">
                        RM {dest.price}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-[#007bff] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Easy Search</h3>
              <p className="text-gray-600">Find the best flights with our intuitive search system</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-[#007bff] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Flexible Booking</h3>
              <p className="text-gray-600">Book now, pay later with flexible payment options</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-[#007bff] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">24/7 Support</h3>
              <p className="text-gray-600">Our team is always here to help you</p>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}