import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Clock, Plane, Filter } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { mockFlights } from '@/data/mockData';
import { Flight } from '@/types';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';

export default function SearchPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [flights] = useState<Flight[]>(mockFlights);
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);

  const handleFlightSelect = (flight: Flight) => {
    if (!user) {
      navigate('/auth', { state: { from: '/search', flight } });
      return;
    }
    navigate('/booking', { state: { flight } });
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-24 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (flights.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <img 
          src="https://images.unsplash.com/photo-1488085061387-422e29b40080?w=400&q=80" 
          alt="No flights"
          className="w-64 h-64 mx-auto mb-8 opacity-50"
        />
        <h2 className="text-2xl font-bold mb-4">No Flights Found</h2>
        <p className="text-gray-600 mb-8">Try adjusting your search criteria</p>
        <Button onClick={() => navigate('/')} className="bg-[#007bff] hover:bg-[#0056b3]">
          Back to Search
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Available Flights</h1>
          <p className="text-gray-600">
            {flights.length} flights found
          </p>
        </div>

        {/* Filters */}
        <div className="mb-6 flex gap-4 flex-wrap">
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Price
          </Button>
          <Button variant="outline" className="gap-2">
            <Clock className="h-4 w-4" />
            Departure Time
          </Button>
          <Button variant="outline" className="gap-2">
            <Plane className="h-4 w-4" />
            Airline
          </Button>
        </div>

        {/* Flight Cards */}
        <div className="space-y-4">
          {flights.map((flight, index) => (
            <motion.div
              key={flight.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Card className="hover:shadow-lg transition-all duration-300 hover:scale-[1.01]">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    {/* Airline Info */}
                    <div className="flex items-center gap-4">
                      <img 
                        src={flight.airlineLogo} 
                        alt={flight.airline}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div>
                        <h3 className="font-bold text-lg">{flight.airline}</h3>
                        <p className="text-sm text-gray-600">{flight.flightNumber}</p>
                      </div>
                    </div>

                    {/* Flight Details */}
                    <div className="flex-1 flex items-center justify-between gap-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold">{flight.departureTime}</p>
                        <p className="text-sm text-gray-600">{flight.origin}</p>
                      </div>

                      <div className="flex-1 flex flex-col items-center">
                        <p className="text-sm text-gray-600 mb-1">{flight.duration}</p>
                        <div className="w-full h-px bg-gray-300 relative">
                          <Plane className="h-4 w-4 text-[#007bff] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 rotate-90" />
                        </div>
                        <p className="text-xs text-gray-500 mt-1">Direct</p>
                      </div>

                      <div className="text-center">
                        <p className="text-2xl font-bold">{flight.arrivalTime}</p>
                        <p className="text-sm text-gray-600">{flight.destination}</p>
                      </div>
                    </div>

                    {/* Price & Action */}
                    <div className="flex flex-col items-end gap-3">
                      <Badge variant="secondary">{flight.class}</Badge>
                      <div className="text-right">
                        <p className="text-3xl font-bold text-[#007bff]">
                          RM {flight.price}
                        </p>
                        <p className="text-xs text-gray-600">{flight.availableSeats} seats left</p>
                      </div>
                      <Button 
                        onClick={() => handleFlightSelect(flight)}
                        className="bg-[#007bff] hover:bg-[#0056b3] w-full"
                      >
                        Select Flight
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}