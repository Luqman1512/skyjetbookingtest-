import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Passenger, Booking } from '@/types';
import { CreditCard, Wallet, Building2, Plane, Calendar, Clock } from 'lucide-react';

export default function BookingPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, addBooking } = useAuth();
  const { toast } = useToast();
  const flight = (location.state as any)?.flight;

  const [step, setStep] = useState(1);
  const [passengers, setPassengers] = useState<Passenger[]>([{
    firstName: '',
    lastName: '',
    email: user?.email || '',
    phone: user?.phone || '',
    dateOfBirth: '',
    passportNumber: ''
  }]);
  const [selectedSeats, setSelectedSeats] = useState<string[]>(['12A']);
  const [paymentMethod, setPaymentMethod] = useState('credit-card');

  if (!flight) {
    navigate('/search');
    return null;
  }

  const handlePassengerChange = (index: number, field: keyof Passenger, value: string) => {
    const updated = [...passengers];
    updated[index] = { ...updated[index], [field]: value };
    setPassengers(updated);
  };

  const handleContinue = () => {
    if (step === 1) {
      // Validate passenger details
      const isValid = passengers.every(p => 
        p.firstName && p.lastName && p.email && p.phone && p.dateOfBirth
      );
      if (!isValid) {
        toast({
          title: 'Error',
          description: 'Please fill in all passenger details.',
          variant: 'destructive'
        });
        return;
      }
      setStep(2);
    } else if (step === 2) {
      setStep(3);
    }
  };

  const handlePayment = () => {
    const booking: Booking = {
      id: Date.now().toString(),
      userId: user!.id,
      flight,
      passengers,
      seats: selectedSeats,
      totalPrice: flight.price * passengers.length,
      status: 'Success',
      bookingDate: new Date().toISOString(),
      paymentMethod
    };

    addBooking(booking);
    navigate('/confirmation', { state: { booking } });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Progress Steps */}
          <div className="mb-8">
            <div className="flex items-center justify-center gap-4">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                    step >= s ? 'bg-[#007bff] text-white' : 'bg-gray-300 text-gray-600'
                  }`}>
                    {s}
                  </div>
                  {s < 3 && <div className={`w-24 h-1 ${step > s ? 'bg-[#007bff]' : 'bg-gray-300'}`} />}
                </div>
              ))}
            </div>
            <div className="flex justify-center gap-32 mt-2 text-sm">
              <span className={step >= 1 ? 'text-[#007bff] font-medium' : 'text-gray-500'}>Passenger Details</span>
              <span className={step >= 2 ? 'text-[#007bff] font-medium' : 'text-gray-500'}>Seat Selection</span>
              <span className={step >= 3 ? 'text-[#007bff] font-medium' : 'text-gray-500'}>Payment</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {step === 1 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Passenger Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {passengers.map((passenger, index) => (
                      <div key={index} className="space-y-4 p-4 border rounded-lg">
                        <h3 className="font-semibold">Passenger {index + 1}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>First Name</Label>
                            <Input
                              value={passenger.firstName}
                              onChange={(e) => handlePassengerChange(index, 'firstName', e.target.value)}
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Last Name</Label>
                            <Input
                              value={passenger.lastName}
                              onChange={(e) => handlePassengerChange(index, 'lastName', e.target.value)}
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Email</Label>
                            <Input
                              type="email"
                              value={passenger.email}
                              onChange={(e) => handlePassengerChange(index, 'email', e.target.value)}
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Phone</Label>
                            <Input
                              value={passenger.phone}
                              onChange={(e) => handlePassengerChange(index, 'phone', e.target.value)}
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Date of Birth</Label>
                            <Input
                              type="date"
                              value={passenger.dateOfBirth}
                              onChange={(e) => handlePassengerChange(index, 'dateOfBirth', e.target.value)}
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Passport Number (Optional)</Label>
                            <Input
                              value={passenger.passportNumber}
                              onChange={(e) => handlePassengerChange(index, 'passportNumber', e.target.value)}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {step === 2 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Select Your Seats</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-6 gap-2">
                        {['A', 'B', 'C', 'D', 'E', 'F'].map((letter) => (
                          <div key={letter} className="text-center font-bold text-gray-600">{letter}</div>
                        ))}
                        {Array.from({ length: 20 }, (_, i) => i + 1).map((row) => (
                          ['A', 'B', 'C', 'D', 'E', 'F'].map((letter) => {
                            const seat = `${row}${letter}`;
                            const isSelected = selectedSeats.includes(seat);
                            const isOccupied = Math.random() > 0.7;
                            return (
                              <button
                                key={seat}
                                onClick={() => {
                                  if (!isOccupied) {
                                    setSelectedSeats(isSelected 
                                      ? selectedSeats.filter(s => s !== seat)
                                      : [...selectedSeats, seat]
                                    );
                                  }
                                }}
                                disabled={isOccupied}
                                className={`p-2 rounded text-sm font-medium transition-all ${
                                  isSelected 
                                    ? 'bg-[#007bff] text-white' 
                                    : isOccupied 
                                    ? 'bg-gray-300 cursor-not-allowed' 
                                    : 'bg-gray-100 hover:bg-gray-200'
                                }`}
                              >
                                {seat}
                              </button>
                            );
                          })
                        ))}
                      </div>
                      <div className="flex gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-gray-100 rounded" />
                          <span>Available</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-[#007bff] rounded" />
                          <span>Selected</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-gray-300 rounded" />
                          <span>Occupied</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {step === 3 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Method</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-4">
                      <div className="flex items-center space-x-2 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                        <RadioGroupItem value="credit-card" id="credit-card" />
                        <Label htmlFor="credit-card" className="flex items-center gap-2 cursor-pointer flex-1">
                          <CreditCard className="h-5 w-5 text-[#007bff]" />
                          <span>Credit / Debit Card</span>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                        <RadioGroupItem value="e-wallet" id="e-wallet" />
                        <Label htmlFor="e-wallet" className="flex items-center gap-2 cursor-pointer flex-1">
                          <Wallet className="h-5 w-5 text-[#007bff]" />
                          <span>E-Wallet (GrabPay, Touch 'n Go)</span>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                        <RadioGroupItem value="fpx" id="fpx" />
                        <Label htmlFor="fpx" className="flex items-center gap-2 cursor-pointer flex-1">
                          <Building2 className="h-5 w-5 text-[#007bff]" />
                          <span>Online Banking (FPX)</span>
                        </Label>
                      </div>
                    </RadioGroup>

                    {paymentMethod === 'credit-card' && (
                      <div className="mt-6 space-y-4">
                        <div className="space-y-2">
                          <Label>Card Number</Label>
                          <Input placeholder="1234 5678 9012 3456" />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Expiry Date</Label>
                            <Input placeholder="MM/YY" />
                          </div>
                          <div className="space-y-2">
                            <Label>CVV</Label>
                            <Input placeholder="123" type="password" maxLength={3} />
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              <div className="flex gap-4 mt-6">
                {step > 1 && (
                  <Button variant="outline" onClick={() => setStep(step - 1)} className="flex-1">
                    Back
                  </Button>
                )}
                <Button 
                  onClick={step === 3 ? handlePayment : handleContinue}
                  className="flex-1 bg-[#007bff] hover:bg-[#0056b3]"
                >
                  {step === 3 ? 'Complete Payment' : 'Continue'}
                </Button>
              </div>
            </div>

            {/* Booking Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Plane className="h-4 w-4 text-[#007bff]" />
                      <span className="font-medium">{flight.airline}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <span>{flight.origin}</span>
                      <span>→</span>
                      <span>{flight.destination}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-gray-500" />
                      <span>{flight.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <span>{flight.departureTime} - {flight.arrivalTime}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Passengers</span>
                      <span>{passengers.length}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Seats</span>
                      <span>{selectedSeats.join(', ')}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Price per ticket</span>
                      <span>RM {flight.price}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span className="text-[#007bff]">RM {flight.price * passengers.length}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}