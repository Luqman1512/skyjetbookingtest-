export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
}

export interface Flight {
  id: string;
  airline: string;
  airlineLogo: string;
  flightNumber: string;
  origin: string;
  destination: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
  class: 'Economy' | 'Business' | 'First';
  availableSeats: number;
  date: string;
}

export interface Booking {
  id: string;
  userId: string;
  flight: Flight;
  passengers: Passenger[];
  seats: string[];
  totalPrice: number;
  status: 'Success' | 'Processing' | 'Cancelled';
  bookingDate: string;
  paymentMethod: string;
}

export interface Passenger {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  passportNumber?: string;
}