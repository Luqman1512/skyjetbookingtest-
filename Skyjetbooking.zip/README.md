# SkyJet Booking Test

A modern, professional flight booking web application with a sky blue and white theme, featuring a clean minimal design with real airplane imagery and smooth animations.

## Features

- **Flight Search**: Search for flights with origin/destination, dates, passengers, and class selection
- **Booking Flow**: Multi-step booking process with passenger details, seat selection, and payment
- **User Authentication**: Login/signup with profile management
- **Booking History**: View and manage past bookings
- **Responsive Design**: Mobile-first approach optimized for all screen sizes

## Tech Stack

- React 18 with TypeScript
- Tailwind CSS for styling
- Framer Motion for animations
- React Router for navigation
- ShadCN UI components

## Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Project Structure

```
src/
├── components/     # Reusable UI components
├── contexts/       # React context providers
├── data/          # Mock data for demo
├── pages/         # Page components
├── types/         # TypeScript type definitions
└── lib/           # Utility functions
```

## License

© 2025 SkyJet Booking Test. All rights reserved.
